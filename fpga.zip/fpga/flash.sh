sudo python3 /home/arun/TinyFPGA-Programmer-Application/tinyfpga-programmer-gui.py --port /dev/ttyACM0  --appfpga top.bin --m4app  blink.bin --mode m4-fpga --reset
